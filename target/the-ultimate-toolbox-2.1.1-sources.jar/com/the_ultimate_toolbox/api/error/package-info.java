/**
 * Submódulo error del módulo api de The Ultimate Toolbox.
 *
 * <p>Este paquete contiene clases específicas para el componente error de api.</p>
 *
 * @author The Ultimate Toolbox Team
 * @version 1.0
 * @since 1.0
 */
package com.the_ultimate_toolbox.api.error;