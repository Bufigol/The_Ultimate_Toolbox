/**
 * Submódulo collection del módulo util de The Ultimate Toolbox.
 *
 * <p>Este paquete contiene clases específicas para el componente collection de util.</p>
 *
 * @author The Ultimate Toolbox Team
 * @version 1.0
 * @since 1.0
 */
package com.the_ultimate_toolbox.util.collection;